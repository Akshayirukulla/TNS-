package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Certificate;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.CertificateRepository;
import com.example.repository.EmployeeRepository;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class CertificateController {

	@Autowired
	private CertificateRepository repository;
	
	// get all employees
	@GetMapping("/certificate")
	public List<Certificate> getAllCertificates(){
		return repository.findAll();
	}		
	
	// create employee rest api
	@PostMapping("/certificate")
	public Certificate createCertificate(@RequestBody Certificate certificate) {
		return repository.save(certificate);
	}
	
	// get employee by id rest api
	@GetMapping("/certificate/{id}")
	public ResponseEntity<Certificate> getCertificateById(@PathVariable Long id) {
		Certificate certificate = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Certificate not exist with id :" + id));
		return ResponseEntity.ok(certificate) ;
	}
	// update employee rest api
	
	@PutMapping("/certificate/{id}")
	public ResponseEntity<Certificate> updateCertificate(@PathVariable Long id, @RequestBody Certificate certificateDetails){
		Certificate certificate = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Certificate not exist with id :" + id));
		
		
		certificate.setYear(certificateDetails.getYear());
		certificate.setCollege(certificateDetails.getCollege());
		
		Certificate updatedCertificate = repository.save(certificate);
		return ResponseEntity.ok(updatedCertificate);
	}
	
	// delete employee rest api
	@DeleteMapping("/certificate/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteCertificate(@PathVariable Long id){
		Certificate certificate = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		repository.delete(certificate);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}